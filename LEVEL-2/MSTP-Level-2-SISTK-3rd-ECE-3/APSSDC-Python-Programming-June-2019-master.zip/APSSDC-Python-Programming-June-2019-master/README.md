# APSSDC-Python-Programming-June-2019
This repository contains all the resources related to the Problem Solving and Programming in Python course offered to APSSDC trainers and students participating in TCS Codevita 2019.
